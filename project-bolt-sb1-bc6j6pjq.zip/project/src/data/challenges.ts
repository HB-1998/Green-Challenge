export const challenges = [
  {
    id: 1,
    title: "Bringing your own water bottle, handkerchief",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 2,
    title: "Reusable bag & food container instead of disposables",
    image: "https://images.unsplash.com/photo-1610720657521-1243f7a4e230?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 3,
    title: "Deleting redundant data and optimising cloud data usage",
    image: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&q=80&w=600",
    note: "Water saved: 1-200L and electricity saved: 3-7 KWH for reduction in every single GB",
  },
  {
    id: 4,
    title: "Unsubscribing from newsletters, content that we hardly read",
    image: "https://images.unsplash.com/photo-1557200134-90327ee9fafa?auto=format&fit=crop&q=80&w=600",
    note: "Water saved: 1-200L and electricity saved: 3-7 KWH for reduction in every single GB",
  },
  {
    id: 5,
    title: "Repair your things",
    image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 6,
    title: "Repair your clothes instead of buying a new one",
    image: "https://images.unsplash.com/photo-1584661156681-540e80a161d3?auto=format&fit=crop&q=80&w=600",
    note: "A new dress can consume as minimum as 2000 litres of water. Every stitch saves more than 2000 litres of water",
  },
  {
    id: 7,
    title: "Turn off devices when not in use and not leave in standby mode",
    image: "https://images.unsplash.com/photo-1592833159155-c62df1b65634?auto=format&fit=crop&q=80&w=600",
    note: "3-10% saving in electricity bill",
  },
  {
    id: 8,
    title: "Check for water aerators",
    image: "https://images.unsplash.com/photo-1585664811087-47f65abbad64?auto=format&fit=crop&q=80&w=600",
    note: "Water aerator reduces flow rate & saves in water bill up to 50%",
  },
  {
    id: 9,
    title: "Optimised AI prompt",
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=600",
    note: "Every single AI prompt can consume energy ranging from 0.3 watt to 40 watt-hours",
  },
  {
    id: 10,
    title: "Turning off engine while waiting in signal/jam for more than a minute",
    image: "https://images.unsplash.com/photo-1611716524065-622312678d68?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 11,
    title: "Encourage vehicle pooling",
    image: "https://images.unsplash.com/photo-1532939163844-547f958e91b4?auto=format&fit=crop&q=80&w=600",
  },
];