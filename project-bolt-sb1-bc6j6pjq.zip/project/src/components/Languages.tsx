import React from 'react';
import { languages } from '../data/languages';

interface LanguagesProps {
  onSelectLanguage: (code: string) => void;
}

export function Languages({ onSelectLanguage }: LanguagesProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh]">
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Select Your Language</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {languages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => onSelectLanguage(lang.code)}
            className="px-8 py-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow
                     text-lg font-medium text-gray-800 border-2 border-green-500
                     hover:bg-green-50 focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            {lang.name}
          </button>
        ))}
      </div>
    </div>
  );
}