import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { languages } from '../data/languages';

interface VideoPlayerProps {
  language: string;
  onVideoEnd: () => void;
  onBackClick: () => void;
}

export function VideoPlayer({ language, onVideoEnd, onBackClick }: VideoPlayerProps) {
  const videoUrl = languages.find(lang => lang.code === language)?.videoUrl;

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh]">
      <div className="w-full max-w-4xl bg-white rounded-lg shadow-lg p-6">
        <button
          onClick={onBackClick}
          className="mb-4 flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Language Selection
        </button>
        
        <div className="aspect-w-16 aspect-h-9 mb-4">
          <iframe
            src={videoUrl}
            className="w-full h-[500px] rounded-lg"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
        
        <button
          onClick={onVideoEnd}
          className="mt-4 px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700
                   transition-colors focus:outline-none focus:ring-2 focus:ring-green-500"
        >
          Continue to Challenges
        </button>
      </div>
    </div>
  );
}