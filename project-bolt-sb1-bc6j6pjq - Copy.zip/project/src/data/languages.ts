export const languages = [
  { 
    code: 'en', 
    name: 'English', 
    videoUrl: 'https://drive.google.com/file/d/1FYVr6e0nlQg7ll4_kKjmmQcfH954IgMT/preview'
  },
  { 
    code: 'hi', 
    name: 'हिंदी', 
    videoUrl: 'https://drive.google.com/file/d/1FYVr6e0nlQg7ll4_kKjmmQcfH954IgMT/preview'
  },
  { 
    code: 'ta', 
    name: 'தமிழ்', 
    videoUrl: 'https://drive.google.com/file/d/1FYVr6e0nlQg7ll4_kKjmmQcfH954IgMT/preview'
  },
  { 
    code: 'te', 
    name: 'తెలుగు', 
    videoUrl: 'https://drive.google.com/file/d/1FYVr6e0nlQg7ll4_kKjmmQcfH954IgMT/preview'
  },
  { 
    code: 'kn', 
    name: 'ಕನ್ನಡ', 
    videoUrl: 'https://drive.google.com/file/d/1FYVr6e0nlQg7ll4_kKjmmQcfH954IgMT/preview'
  },
  { 
    code: 'ml', 
    name: 'മലയാളം', 
    videoUrl: 'https://drive.google.com/file/d/1FYVr6e0nlQg7ll4_kKjmmQcfH954IgMT/preview'
  }
];