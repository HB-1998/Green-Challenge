import React from 'react';
import { ArrowLeft, Play, Home } from 'lucide-react';
import { challenges } from '../data/challenges';
import { translations } from '../data/translations';

interface ChallengesProps {
  onWatchAgain: () => void;
  onBackToHome: () => void;
  language: string;
}

export function Challenges({ onWatchAgain, onBackToHome, language }: ChallengesProps) {
  const t = translations[language];

  return (
    <div className="flex flex-col items-center">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {challenges.map((challenge) => (
          <div
            key={challenge.id}
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
          >
            <img
              src={challenge.image}
              alt={t.challenges[challenge.id].title}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {t.challenges[challenge.id].title}
              </h3>
              {t.challenges[challenge.id].note && (
                <p className="text-sm text-gray-600 italic">
                  {t.challenges[challenge.id].note}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-center justify-center mb-8">
        <button
          onClick={onWatchAgain}
          className="flex items-center px-6 py-3 bg-green-600 text-white rounded-lg
                   hover:bg-green-700 transition-colors focus:outline-none focus:ring-2
                   focus:ring-green-500"
        >
          <Play className="h-5 w-5 mr-2" />
          {t.watchAgain}
        </button>
        <button
          onClick={onBackToHome}
          className="flex items-center px-6 py-3 bg-gray-600 text-white rounded-lg
                   hover:bg-gray-700 transition-colors focus:outline-none focus:ring-2
                   focus:ring-gray-500"
        >
          <Home className="h-5 w-5 mr-2" />
          {t.backToHome}
        </button>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md max-w-2xl w-full">
        <h3 className="text-xl font-bold text-gray-900 mb-4">{t.contactInfo}</h3>
        <div className="space-y-2 text-gray-600">
          <p>{t.email}</p>
          <p>{t.phone}</p>
          <p>{t.social}</p>
        </div>
      </div>
    </div>
  );
}